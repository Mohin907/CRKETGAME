const functions = require('firebase-functions');
const admin = require('firebase-admin');
admin.initializeApp();

exports.startMatch = functions.https.onRequest(async (req, res) => {
  const userId = req.query.userId || "guest";
  const bonus = 5;

  try {
    await admin.database().ref(`/users/${userId}/matches`).push({
      startedAt: Date.now(),
      overs: 2
    });

    const walletRef = admin.database().ref(`/users/${userId}/wallet`);
    const snapshot = await walletRef.once('value');
    const current = snapshot.val() || 0;
    await walletRef.set(current + bonus);

    res.status(200).send("Game Started! ₹5 coins added.");
  } catch (err) {
    res.status(500).send("Error starting game: " + err.message);
  }
});